# 1.1.1

Added missing dll

# 1.1.0

Fixed OC crash

# 1.0.0

Initial release.