# 1.2.0

Potential fix for Distracting Act.

Updated White Practise

Increased Rarity of Throwing Card upgrades

# 1.1.2

Temporary fix for issue with persistent freezes caused by unsetting the mage subclass

# 1.1.1

Added missing dll

# 1.1.0

Fixed OC crash

# 1.0.0

Initial release.
